const express = require('express');
const bodyparser = require('body-parser');
const app = express();

//parses incoming request bodies in a middleware before your handlers, available under the req.body property.
app.use(bodyparser.urlencoded({extended: true}));

app.get('',(req, res) => {
    res.sendFile(__dirname +"/index.html");
})

app.post('',(req, res) => {
    const n1=Number(req.body.num1)
    // console.log(n1);
    const n2=Number(req.body.num2)
    const add=n1 + n2;
    const multiply=n1 * n2;
    const minus = n1-n2;
    const divide = n1 / n2;
    if( req.body.add)
    res.send('the value of '+n1 +"+"+n2+' is: '+add);
     if(req.body.multiply)
    res.send('the value of '+n1 +"*"+n2+' is: '+multiply);
    if( req.body.minus)
    res.send('the value of '+n1 +"-"+n2+' is: '+minus);
     if(req.body.divide)
    res.send('the value of '+n1 +"/"+n2+' is: '+divide);
})


app.listen(3000,(res)=>{
    console.log('Server is ON port 3000')
})